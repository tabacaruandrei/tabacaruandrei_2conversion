#include <fstream>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    int n, p, q, y=0, c=1;
    int m[100][100];
    int cont;
    fin>>n;
    fin>>cont;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            m[i][j]=0;
    fin>>p>>q;
    while(y<cont)
    {
        m[p][0]++;
        while(c<=n)
        {
            if(m[p][c]==0)
            {
                m[p][c]=q;
                break;
            }
            c++;
        }
        c=1;
        m[q][0]++;
        while(c<=n)
        {
            if(m[q][c]==0)
            {
                m[q][c]=p;
                break;
            }
            c++;
        }
        c=1;
        fin>>p>>q;
        y++;
    }
    for(int i=1;i<=n;i++)
     {
        for(int j=0;j<=n;j++)
            fout<<m[i][j]<<" ";
        fout<<endl;
     }
}
